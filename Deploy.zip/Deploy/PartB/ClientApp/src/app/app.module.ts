import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GlossaryTermsComponent } from './glossary-terms/glossary-terms.component';
import { GlossaryTermComponent } from './glossary-term/glossary-term.component';
import { GlossaryTermAddEditComponent } from './glossary-term-add-edit/glossary-term-add-edit.component';
import {GlossaryTermService} from './services/glossary-term.service';
import { OrderModule } from './order-pipe/ngx-order.module';


@NgModule({
  declarations: [
    AppComponent,
    GlossaryTermsComponent,
    GlossaryTermComponent,
    GlossaryTermAddEditComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule,
    OrderModule
  ],
  providers: [
    GlossaryTermService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
