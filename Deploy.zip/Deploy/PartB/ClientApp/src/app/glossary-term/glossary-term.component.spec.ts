import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlossaryTermComponent } from './glossary-term.component';

describe('GlossaryTermComponent', () => {
  let component: GlossaryTermComponent;
  let fixture: ComponentFixture<GlossaryTermComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlossaryTermComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlossaryTermComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
