import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import {GlossaryTermService} from '../services/glossary-term.service';
import {GlossaryTerm} from '../models/glossaryterm';


@Component({
  selector: 'app-glossary-term',
  templateUrl: './glossary-term.component.html',
  styleUrls: ['./glossary-term.component.scss']
})
export class GlossaryTermComponent implements OnInit {
  glossaryTerm$: Observable<GlossaryTerm>;
  id: number;
  constructor(private glossaryTermService: GlossaryTermService, private avRoute: ActivatedRoute) {
    const idParam = 'id';
    if (this.avRoute.snapshot.params[idParam]) {
      this.id = this.avRoute.snapshot.params[idParam];
    }
  }

  ngOnInit() {
    this.loadGlossaryTerms();
  }

  loadGlossaryTerms() {
    this.glossaryTerm$ = this.glossaryTermService.GlossaryTerm(this.id);
  }
}