import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import {GlossaryTermService} from '../services/glossary-term.service';
import {GlossaryTerm} from '../models/glossaryterm';
import { OrderPipe } from '../order-pipe/ngx-order.pipe';

@Component({
  selector: 'app-glossary-terms',
  templateUrl: './glossary-terms.component.html',
  styleUrls: ['./glossary-terms.component.scss']
})
export class GlossaryTermsComponent implements OnInit {

  glossaryTerms$: Observable<GlossaryTerm[]>;
  order: string = 'glossaryTerm.term';
  reverse: boolean = true;
  isDesc: boolean;
  constructor(private glossaryTermService: GlossaryTermService, private orderPipe: OrderPipe) {
    console.log(this.orderPipe.transform(this.reverse, this.order));
  }

  ngOnInit() {
    this.loadGlossaryTerms();
  }

  loadGlossaryTerms() {
    this.glossaryTerms$ = this.glossaryTermService.getGlossaryTerms();
  }
  delete(id) {
    const ans = confirm('Do you want to delete glossary term with id: ' + id);
    if (ans) {
      this.glossaryTermService.deleteGlossaryTerm(id).subscribe((data) => {
        this.loadGlossaryTerms();
      });
    }
  }
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value;
  }
}
