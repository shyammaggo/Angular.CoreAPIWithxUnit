export class GlossaryTerm {
     id?: number;
     term: string;
     definition: string;

    // postId?: number;
    // creator: string;
    // title: string;
    // body: string;
    // dt: Date;
  }