import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {GlossaryTermsComponent} from './glossary-terms/glossary-terms.component';
import {GlossaryTermComponent} from './glossary-term/glossary-term.component';
import {GlossaryTermAddEditComponent} from './glossary-term-add-edit/glossary-term-add-edit.component';
const routes: Routes = [
  { path: '', component: GlossaryTermsComponent, pathMatch: 'full' },
  { path: 'glossaryterm/:id', component: GlossaryTermComponent },
  { path: 'add', component: GlossaryTermAddEditComponent },
  { path: 'glossaryterm/edit/:id', component: GlossaryTermAddEditComponent },
  { path: '**', redirectTo: '/' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
