import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import {GlossaryTermService} from '../services/glossary-term.service';
import {GlossaryTerm} from '../models/glossaryterm';


@Component({
  selector: 'app-glossary-term-add-edit',
  templateUrl: './glossary-term-add-edit.component.html',
  styleUrls: ['./glossary-term-add-edit.component.scss']
})


export class GlossaryTermAddEditComponent implements OnInit {
  form: FormGroup;
  actionType: string;
  formTerm: string;
  formDefinition: string;
  Id: number;
  errorMessage: any;
  existingGlossaryTerm: GlossaryTerm;

  // tslint:disable-next-line: max-line-length
  constructor(private glossaryTermService: GlossaryTermService, private formBuilder: FormBuilder, private avRoute: ActivatedRoute, private router: Router)
   {
    const idG = 'id';
    this.actionType = 'Add';
    this.formTerm = 'term';
    this.formDefinition = 'definition';
    if (this.avRoute.snapshot.params[idG]) {
      this.Id = this.avRoute.snapshot.params[idG];
    }

    this.form = this.formBuilder.group(
      {
        term: ['', [Validators.required]],
        definition: ['', [Validators.required]],
      }
    );
  }

  ngOnInit() {

    if (this.Id > 0) {
      this.actionType = 'Edit';
      this.glossaryTermService.GlossaryTerm(this.Id)
        .subscribe(data => (
          this.existingGlossaryTerm = data,
          this.form.controls[this.formTerm].setValue(data.term),
          this.form.controls[this.formDefinition].setValue(data.definition)
        ));
    }
  }

  save() {
    if (!this.form.valid) {
      const ans = alert('form is blank. please fill data.');
      return;
    }

    if (this.actionType === 'Add') {
      let glossaryTerm: GlossaryTerm = {
        term: this.form.get(this.formTerm).value,
        definition: this.form.get(this.formDefinition).value
      };
      this.glossaryTermService.saveGlossaryTerm(glossaryTerm)
        .subscribe((data) => {
          this.router.navigate(['/glossaryterm', data.id]);
        });
    }

    if (this.actionType === 'Edit') {
      let glossaryTerm: GlossaryTerm = {
        id: this.existingGlossaryTerm.id,
        term: this.form.get(this.formTerm).value,
        definition: this.form.get(this.formDefinition).value
      };
      this.glossaryTermService.updateGlossaryTerm(glossaryTerm.id, glossaryTerm)
        .subscribe((data) => {
          this.router.navigate(['/glossaryterm']);
        });
    }
  }

  cancel() {
    this.router.navigate(['/']);
  }

  get title() { return this.form.get(this.formTerm); }
  get body() { return this.form.get(this.formDefinition); }
}
