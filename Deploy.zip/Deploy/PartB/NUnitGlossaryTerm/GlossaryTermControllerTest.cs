﻿using Castle.Core.Logging;
using Glossary.API.Controllers;
using Glossary.BusinessObjects;
using Glossary.Domain;
using Glossary.Repositories;
using Logger;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnitGlossaryTerm
{
    public class GlossaryTermControllerTest
    {
        private Mock<IGenericRepository<GlossaryTerm>> glossaryDB;
        private Mock<IGlossaryTermBO> glosaryTermBO;
        private List<GlossaryTerm> glossaryRepository;
        GlossaryTermsController ctrl;
        private Mock<ILog> logger;
        GlossaryTerm gt1;
        GlossaryTerm gt2;
        public GlossaryTermControllerTest()
        {
            glossaryDB = new Mock<IGenericRepository<GlossaryTerm>>();
            glossaryRepository = new List<GlossaryTerm>();
            gt1 = new GlossaryTerm() { Id = 1, Term = "A", Definition = "AA" };
            gt2 = new GlossaryTerm() { Id = 2, Term = "B", Definition = "BB" };
            glossaryRepository.Add(gt1);
            glossaryRepository.Add(gt2);

            glosaryTermBO = new Mock<IGlossaryTermBO>();
            logger = new Mock<ILog>();
            ctrl = new GlossaryTermsController(glosaryTermBO.Object, logger.Object);
        }
        [Test]
        public async Task TestGetAllGlossaryTerms()
        {
            //Act
            glossaryDB.Setup(a => a.GetAll()).Returns(new Task<IEnumerable<GlossaryTerm>>(() => glossaryRepository));

            var res =await ctrl.GetGlossaryTerms();
            var model = res.Value as List<GlossaryTerm>;
            CollectionAssert.Contains(model, gt1);

        }
    }
}
