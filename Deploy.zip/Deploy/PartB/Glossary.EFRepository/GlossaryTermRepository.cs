﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Glossary.Domain;
using Glossary.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Glossary.EFRepository
{
    /// <summary>
    /// This class is the Repository for the GlossaryTerm. GlossaryTerm Domain classs is passed in the Generic Repository Implementation 
    /// and  GlossaryTerm Repository Interface is inherited.
    /// </summary>
    public class GlossaryTermRepository : GenericRepository<GlossaryTerm>, IGlossaryTermRepository
    {
        GlossaryContext _context;
        public GlossaryTermRepository(GlossaryContext context) : base(context)
        {
            _context = context;
        }
    }
}
