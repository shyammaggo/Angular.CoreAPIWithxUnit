﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Glossary.Repositories;
using System.Linq;
using Microsoft.Extensions.Caching.Memory;

namespace Glossary.EFRepository
{
    /// <summary>
    /// This is the implementation of the Generic Repository interface. 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        DbContext _context;
        DbSet<T> ds;
        
        public GenericRepository(DbContext context)
        {
            _context = context;
            ds = _context.Set<T>();
          
        }
        /// <summary>
        /// Get All Glossary Term records.
        /// </summary>
        /// <returns></returns>
        public async virtual Task<IEnumerable<T>> GetAll()
        {
            IEnumerable<T> dsTemp = null;
            Type tp = typeof(T);
            string type = tp.ToString();
           
            if (dsTemp == null)
            {
                dsTemp = await ds.ToListAsync();
               
            }
            return dsTemp;
        }

        /// <summary>
        /// Get the Glossary Term record based on the Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async virtual Task<T> GetById(int id)
        {
            return await ds.FindAsync(id);
        }
        public async virtual Task<T> Add(T entity)
        {
            ds.Add(entity);
            await _context.SaveChangesAsync();
            Type tp = typeof(T);
            string type = tp.ToString();
            
            return entity;
        }

        /// <summary>
        /// Update the Glossary Term record.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async virtual Task Update(T entity)
        {
            _context.Entry<T>(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            Type tp = typeof(T);
            string type = tp.ToString();
          
        }
        /// <summary>
        /// Delete the Glossary Term record.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async virtual Task Delete(int id)
        {
            T entity = ds.Find(id);
            ds.Remove(entity);
            await _context.SaveChangesAsync();
            Type tp = typeof(T);
            string type = tp.ToString();
         
        }
        /// <summary>
        /// Release unmanaged resources
        /// </summary>
        public virtual void Dispose()
        {
            _context.Dispose();
        }
    }
}