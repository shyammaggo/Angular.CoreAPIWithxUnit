﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Glossary.Domain;

namespace Glossary.Repositories
{
    
/// <summary>
/// This is Generic Repository which can be used across the application based on the Type
/// </summary>
/// <typeparam name="T"></typeparam>
   public interface IGenericRepository<T>:IDisposable where T:class 
    {
       Task<IEnumerable<T>> GetAll();
        Task<T> GetById(int id);
        Task<T> Add(T item);
        Task Update(T item);
        Task Delete(int id);

    }
}
