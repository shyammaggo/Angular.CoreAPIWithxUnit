﻿using Glossary.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Glossary.Repositories
{
    /// <summary>
    /// This is GlossaryTerm Repository which Inherits the Generic Repository and passes the GlossaryTerm domain class.
    /// 
    /// </summary>
    public interface IGlossaryTermRepository : IGenericRepository<GlossaryTerm>
    {
       
    }
}
