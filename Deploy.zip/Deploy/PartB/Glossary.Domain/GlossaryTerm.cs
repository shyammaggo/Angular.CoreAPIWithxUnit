﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Glossary.Domain
{
    /// <summary>
    /// Glossary Term Domain class
    /// </summary>
    [Table("GlossaryTerm")]
    public class GlossaryTerm
    {
        public int Id { get; set; }
        public string Term { get; set; }
        public string Definition { get; set; }
    }
}
