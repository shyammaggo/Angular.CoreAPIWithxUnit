﻿using Glossary.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Glossary.Domain
{
    /// <summary>
    /// Glossary Term Seed Data class. When the database is created with the Add-Migration some records are inserted.
    /// </summary>
    public class GlossaryTermsSeed
    {
        public static async Task SeedAsync(GlossaryContext context)
        {
            if (!context.GlossaryTerm.Any())
            {
                context.GlossaryTerm.AddRange(GetPreconfiguredGlossaryTerms());
                await context.SaveChangesAsync();
            }
        }

        static IEnumerable<GlossaryTerm> GetPreconfiguredGlossaryTerms()
        {
            return new List<GlossaryTerm>()
             {
             new GlossaryTerm() { Term="abyssal plain", Definition = "The ocean floor offshore from the continental margin, usually very flat with a slight slope."},
             new GlossaryTerm() { Term="accrete", Definition = "To add terranes (small land masses or pieces of crust) to another, usually larger, land mass."}

             };
        }
    }
}
