﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Glossary.Domain;

namespace Glossary.Domain
{
    /// <summary>
    /// DBContext class for all database operations.
    /// </summary>
    public class GlossaryContext : DbContext
    {
        public GlossaryContext (DbContextOptions<GlossaryContext> options)
            : base(options)
        {
        }

        public DbSet<Glossary.Domain.GlossaryTerm> GlossaryTerm { get; set; }
    }
}
