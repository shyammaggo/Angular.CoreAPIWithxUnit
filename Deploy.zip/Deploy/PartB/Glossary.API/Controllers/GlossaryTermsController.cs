﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using Glossary.Domain;
using Glossary.BusinessObjects;
using System.Runtime.InteropServices;
using Logger;

namespace Glossary.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GlossaryTermsController : ControllerBase
    {
       /// <summary>
       /// 
       /// </summary>
        IGlossaryTermBO _boGlossaryTerm;
        private ILog _logger;
        public GlossaryTermsController(IGlossaryTermBO boGlossaryTerm, ILog logger)
        {
            _boGlossaryTerm = boGlossaryTerm;
            _logger = logger;

        }

        // GET: api/GlossaryTerms
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GlossaryTerm>>> GetGlossaryTerms()
        {
            var items = await _boGlossaryTerm.GetGlossaryTerms();//.GlossaryTerm.ToListAsync();

            _logger.Information("GetAll glossary method called...");
            try
            {
                if (items == null)
                    return NotFound("Glossary list is empty");
            }
            catch (Exception ex)
            {
                _logger.Error("Error is logged >  " + ex.Message);
            }
            return Ok(items);
        }

        // GET: api/GlossaryTerms/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GlossaryTerm>> GetGlossaryTerm(int id)
        {
            _logger.Information("Get one gloassray  term method called...");
            var glossaryTerm = await _boGlossaryTerm.GetGlossaryTermDetails(id);

            if (glossaryTerm == null)
            {
                return NotFound();
            }

            return glossaryTerm;
        }

        // PUT: api/GlossaryTerms/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGlossaryTerm(int id, GlossaryTerm glossaryTerm)
        {
            if (id != glossaryTerm.Id)
            {
                return BadRequest();
            }



            try
            {
                await _boGlossaryTerm.Update(glossaryTerm);
            }
            catch (ApplicationException ex)
            {
                if (ex.Message == "Not Found")
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/GlossaryTerms
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<ActionResult<GlossaryTerm>> PostGlossaryTerm(GlossaryTerm glossaryTerm)
        {

            await _boGlossaryTerm.Add(glossaryTerm);//_context.SaveChangesAsync();

            return CreatedAtAction("GetGlossaryTerm", new { id = glossaryTerm.Id }, glossaryTerm);
        }

        // DELETE: api/GlossaryTerms/5
        [HttpDelete("{id}")]
        public async Task DeleteGlossaryTerm(int id)
        {
            await _boGlossaryTerm.Delete(id);
        }
    }
}
