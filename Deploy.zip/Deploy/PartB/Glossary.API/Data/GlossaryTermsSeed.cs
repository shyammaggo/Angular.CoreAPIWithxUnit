﻿using Glossary.API.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Glossary.API.Data
{
    public class GlossaryTermsSeed
    {
        public static async Task SeedAsync(GlossaryContext context)
        {
            if (!context.GlossaryTerm.Any())
            {
                context.GlossaryTerm.AddRange(GetPreconfiguredGlossaryTerms());
                await context.SaveChangesAsync();
            }
        }

        static IEnumerable<GlossaryTerm> GetPreconfiguredGlossaryTerms()
        {
            return new List<GlossaryTerm>()
             {
             new GlossaryTerm() { Term="abyssal plain", Definition = "The ocean floor offshore from the continental margin, usually very flat with a slight slope."},
             new GlossaryTerm() { Term="accrete", Definition = "To add terranes (small land masses or pieces of crust) to another, usually larger, land mass."}

             };
        }
    }
}
