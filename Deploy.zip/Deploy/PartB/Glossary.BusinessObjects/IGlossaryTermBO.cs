﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Glossary.Domain;
using Glossary.Repositories;

namespace Glossary.BusinessObjects
{
    
    /// <summary>
    /// Glossary Term BO Interface.
    /// </summary>
    public interface IGlossaryTermBO 
    {

        Task<IEnumerable<GlossaryTerm>> GetGlossaryTerms();
        Task<GlossaryTerm> GetGlossaryTermDetails(int id);
        Task<GlossaryTerm> Add(GlossaryTerm item);
        Task Update(GlossaryTerm item);
        Task Delete(int id);
    }
}
