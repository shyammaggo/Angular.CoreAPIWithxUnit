﻿using Glossary.Domain;
using Glossary.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Glossary.BusinessObjects
{
    /// <summary>
    /// Glossary Term Business Object class. 
    /// It inherits the Glossary Term BO Interface
    /// </summary>
    public class GlossaryTermBO : IGlossaryTermBO
    {
        IGlossaryTermRepository _repository;
        public GlossaryTermBO(IGlossaryTermRepository repository)
        {
            _repository = repository;
        }
        public async Task<GlossaryTerm> Add(GlossaryTerm item)
        {
            await _repository.Add(item);
            return item;
        }

        public async Task Delete(int id)
        {
            await _repository.Delete(id);
        }

        public async Task<GlossaryTerm> GetGlossaryTermDetails(int id)
        {
            return await _repository.GetById(id);
        }

        public async Task<IEnumerable<GlossaryTerm>> GetGlossaryTerms()
        {
            return await _repository.GetAll();
        }

        public async Task Update(GlossaryTerm item)
        {
            await _repository.Update(item);
        }
    }
}
